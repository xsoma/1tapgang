#pragma once





extern void GloveChanger();
