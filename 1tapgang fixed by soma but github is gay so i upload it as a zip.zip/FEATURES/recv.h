extern void NetvarHook();
