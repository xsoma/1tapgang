#include "../includes.h"

#include "Checksum_CRC.h"

namespace SDK
{
	CCRC gCRC;
}