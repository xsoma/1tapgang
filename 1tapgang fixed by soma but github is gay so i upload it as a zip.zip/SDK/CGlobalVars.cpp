#include "../includes.h"
#include "../SDK/CGlobalVars.h"

namespace SDK
{
	namespace CGV
	{
		uintptr_t uRandomSeed = NULL;
	}
}