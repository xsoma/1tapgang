#pragma once

namespace SDK
{
	class Collideable
	{

	public:

		virtual void unk0();
		virtual Vector &Mins() const;
		virtual Vector &Maxs() const;
	};
}